module.exports = {
    mongoURI: '',
    jwtSecret: '',
    jwtExpire: '24h',
    cloudinary_cloud_name: '',
    cloudinary_api_key: '',
    cloudinary_api_secret: '',
    googleClient: ""
}
